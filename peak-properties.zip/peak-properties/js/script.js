// ====== EDIT THESE ======
const WHATSAPP_NUMBER = "254700000000"; // country code + number, no "+" or spaces
// ========================

const waUrl = (text) =>
  `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(text)}`;

// All elements with data-wa open WhatsApp with a prefilled message
document.querySelectorAll("[data-wa]").forEach((el) => {
  el.href = waUrl(el.dataset.wa);
  el.target = "_blank";
  el.rel = "noopener";
});

// Mobile menu
const menuBtn = document.querySelector(".menu-btn");
const nav = document.getElementById("nav");
menuBtn.addEventListener("click", () => {
  const open = nav.classList.toggle("open");
  menuBtn.setAttribute("aria-expanded", open);
});
nav.addEventListener("click", (e) => {
  if (e.target.tagName === "A") {
    nav.classList.remove("open");
    menuBtn.setAttribute("aria-expanded", "false");
  }
});

// Contact form -> WhatsApp (only on pages that have it)
const form = document.getElementById("contact-form");
if (form) {
  const note = document.getElementById("form-note");
  form.addEventListener("submit", (e) => {
    e.preventDefault();
    const name = form.name.value.trim();
    const phone = form.phone.value.trim();
    [form.name, form.phone].forEach((f) => f.classList.toggle("invalid", !f.value.trim()));
    if (!name || !phone) {
      note.textContent = "Please enter your name and phone number so we can reply.";
      return;
    }
    note.textContent = "";
    const msg =
      `Hello Peak Properties, my name is ${name}.\n` +
      `I want to: ${form.intent.value}.\n` +
      `Phone: ${phone}\n` +
      (form.message.value.trim() ? `Message: ${form.message.value.trim()}` : "");
    window.open(waUrl(msg), "_blank", "noopener");
    form.reset();
  });
}

// Property filters (properties page)
const chips = document.querySelectorAll(".chip");
if (chips.length) {
  const cards = document.querySelectorAll(".card[data-type]");
  const empty = document.getElementById("empty");
  chips.forEach((chip) =>
    chip.addEventListener("click", () => {
      chips.forEach((c) => c.classList.remove("active"));
      chip.classList.add("active");
      let shown = 0;
      cards.forEach((card) => {
        const show = chip.dataset.filter === "all" || card.dataset.type === chip.dataset.filter;
        card.hidden = !show;
        if (show) shown++;
      });
      empty.hidden = shown > 0;
    })
  );
}

document.getElementById("year").textContent = new Date().getFullYear();
